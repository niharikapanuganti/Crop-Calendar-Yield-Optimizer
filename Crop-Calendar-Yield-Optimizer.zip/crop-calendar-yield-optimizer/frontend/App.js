import {useState} from "react";

function App(){
const [cropType,setCropType]=useState("");
return(
<div>
<h1>Crop Calendar and Yield Optimizer</h1>
<select onChange={(e)=>setCropType(e.target.value)}>
<option>Rice</option>
<option>Wheat</option>
<option>Cotton</option>
</select>
<p>Selected Crop: {cropType}</p>
</div>
)
}

export default App;
