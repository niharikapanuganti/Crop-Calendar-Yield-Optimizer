crop_yield={
"Rice":25,
"Wheat":30,
"Cotton":18
}

crop=input("Enter crop name: ")
print(crop_yield.get(crop,"No data"))
