# Crop Calendar and Yield Optimizer

Technologies:
- React.js
- Node.js
- Python

Features:
- Crop prediction
- Soil recommendation
- Pesticide suggestion
- Market price display
