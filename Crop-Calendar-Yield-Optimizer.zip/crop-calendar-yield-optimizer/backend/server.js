const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const cropData={
Rice:{soil:"Clay Soil",pesticide:"Neem Oil Spray",harvestDays:120,marketPrice:"₹2200/quintal"},
Wheat:{soil:"Loamy Soil",pesticide:"Chlorpyrifos",harvestDays:140,marketPrice:"₹2400/quintal"},
Cotton:{soil:"Black Soil",pesticide:"Imidacloprid",harvestDays:180,marketPrice:"₹7000/quintal"}
};

app.post("/crop",(req,res)=>{
const {cropType,sowingDate}=req.body;
const data=cropData[cropType];

if(!data){
return res.status(404).json({message:"Crop not found"});
}

res.json(data);
});

app.listen(5000,()=>console.log("Server started"));
